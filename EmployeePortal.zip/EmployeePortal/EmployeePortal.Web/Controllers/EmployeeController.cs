﻿using EmployeePortal.Web.Data;
using EmployeePortal.Web.Models;
using EmployeePortal.Web.Models.Entities;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EmployeePortal.Web.Controllers
{
    public class EmployeeController : Controller
    {
        private readonly ApplicationDbContext dbContext;
        public EmployeeController(ApplicationDbContext applicationDbContext)
        {
            dbContext = applicationDbContext;
        }
        public IActionResult Add()
        {
            ViewData["ButtonText"] = "Create";
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Add(EmployeeViewModel employeeViewModel)
        {
            if(!ModelState.IsValid)
            {
                return NotFound();
            }
            Employee employee = new Employee();
            string nextEmployeeId = await GenerateEmployeeID();
            employee.EmployeeId = nextEmployeeId;
            employee.EmployeeName = employeeViewModel.EmployeeName;
            employee.DOB = employeeViewModel.DOB;
            employee.Salary = employeeViewModel.Salary;
            employee.DeptID = employeeViewModel.DeptID;
            employee.Job = employeeViewModel.Job;
            employee.Manager = employeeViewModel.Manager;

            await dbContext.AddAsync(employee);
            await dbContext.SaveChangesAsync();

            return RedirectToAction("List", "Employee");
        }
        public async Task<IActionResult> List(Employee employee)
        {
            var employees = await dbContext.Employees.ToListAsync();
            return View(employees);
        }
        
        public async Task<IActionResult> ViewEmployee(string id)
        {
            if(string.IsNullOrEmpty(id))
            {
                return NotFound();
            }
            var employee = await dbContext.Employees.FindAsync(id);
            return View(employee);
        }
        public async Task<IActionResult> Update(string id)
        {
            if (string.IsNullOrEmpty(id))
            {
                return NotFound();
            }
            var employee = await dbContext.Employees.FindAsync(id);
            
            EmployeeViewModel employeeviewModel = new EmployeeViewModel();
            employeeviewModel.EmployeeName = employee.EmployeeName;
            employeeviewModel.DOB = employee.DOB;
            employeeviewModel.Salary = employee.Salary;
            employeeviewModel.DeptID = employee.DeptID;
            employeeviewModel.Job = employee.Job;
            employeeviewModel.Manager = employee.Manager;

            ViewData["ButtonText"] = "Update";
            return View("Add", employeeviewModel);
        }
        [HttpPost]
        public async Task<IActionResult> Update(string id, EmployeeViewModel employeeViewModel)
        {
            if(string.IsNullOrEmpty(id))
            {
                return NotFound();
            }
            var employee = await dbContext.Employees.FindAsync(id);
            employee.EmployeeName = employeeViewModel.EmployeeName;
            employee.DOB = employee.DOB;
            employee.Salary = employeeViewModel.Salary;
            employee.DeptID = employeeViewModel.DeptID;
            employee.Job = employee.Job;
            employee.Manager = employee.Manager;
            
            await dbContext.SaveChangesAsync();

            ViewData["ButtonText"] = "Update";
            return RedirectToAction("List");
        }
        [HttpPost]
        public async Task<IActionResult> Delete(string id)
        {
            if (string.IsNullOrEmpty(id))
            {
                return NotFound();
            }
            Employee employee = await dbContext.Employees.FindAsync(id);
            dbContext.Employees.Remove(employee);
            await dbContext.SaveChangesAsync();
            return RedirectToAction("List");
        }

        // Helper to generate EmployeeID automatically
        private async Task<string> GenerateEmployeeID()
        {
            int count = dbContext.Employees.Count() + 1;
            return $"Emp{count:D2}";
        }
    }
}
