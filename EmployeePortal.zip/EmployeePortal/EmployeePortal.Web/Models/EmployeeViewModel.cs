﻿namespace EmployeePortal.Web.Models
{
    public class EmployeeViewModel
    {
        public string EmployeeName { get; set; }
        public DateTime DOB { get; set; }
        public float Salary { get; set; }
        public string DeptID { get; set; }
        public string Job { get; set; }
        public string Manager { get; set; }
    }
}
