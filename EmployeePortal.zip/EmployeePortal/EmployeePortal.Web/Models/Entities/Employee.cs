﻿using System.ComponentModel.DataAnnotations;

namespace EmployeePortal.Web.Models.Entities
{
    public class Employee
    {
        [StringLength(8)]
        public string EmployeeId { get; set; }
        [StringLength(20)]
        public string EmployeeName {  get; set; }
        public DateTime DOB { get; set; }
        public float Salary {  get; set; }
        [StringLength(3)]
        public string DeptID { get; set; }
        [StringLength(20)]
        public string Job {  get; set; }
        [StringLength(8)]
        public string Manager {  get; set; }
        
    }
}
