using EmployeePortal.Web.Data;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();

// Registering ApplicationDbContext with the dependency injection (DI) container.
// This allows the ApplicationDbContext to be injected into services, controllers, etc., where needed.
// options.UseSqlServer(...) configures Entity Framework Core to use SQL Server as the database provider.
// builder.Configuration.GetConnectionString("EmployeePortal") retrieves the connection string named "EmployeePortal" 
// from the configuration file (e.g., appsettings.json), which contains the details to connect to the SQL Server database.
builder.Services.AddDbContext<ApplicationDbContext>(options => options.UseSqlServer(builder.Configuration.GetConnectionString("EmployeePortal")));

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
