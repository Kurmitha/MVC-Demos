﻿using Microsoft.AspNetCore.Mvc;
using StudentPortal.Web.Models;
using StudentPortal.Web.Models.Entities;
using StudentPortal.Web.Data;
using Microsoft.EntityFrameworkCore;

namespace StudentPortal.Web.Controllers
{
    public class StudentController : Controller
    {
        private readonly ApplicationDbContext dbContext;
        public StudentController(ApplicationDbContext dbContext)
        {
            this.dbContext = dbContext;
        }
        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }

        [HttpPost]
        public async Task <IActionResult?> Add(StudentViewModel studentViewModel)
        {
            Student student = new Student 
            { 
                Email = studentViewModel.Email, 
                Name = studentViewModel.Name, 
                Phone = studentViewModel.Phone, 
                Subscribed = studentViewModel.Subscribed 
            };
            await dbContext.AddAsync(student);
            await dbContext.SaveChangesAsync();
            return RedirectToAction("List", "Student");
        }

        [HttpGet]
        public async Task<IActionResult> List()
        {
            var students = await dbContext.Students.ToListAsync();
            return View(students);
        }

        [HttpGet]
        public async Task<IActionResult>Edit(Guid id)
        {
            var student = await dbContext.Students.FindAsync(id);
            return View(student);
        }

        [HttpPost]
        public async Task<IActionResult>Edit(Student studentModel)
        {
            var student = await dbContext.Students.FindAsync(studentModel.Id);
            
            if(student is not null)
            {
                student.Name = studentModel.Name;
                student.Email = studentModel.Email;
                student.Phone = studentModel.Phone;
                student.Subscribed = studentModel.Subscribed;
                await dbContext.SaveChangesAsync();
            };
            
            return RedirectToAction("List", "Student");
        }

        [HttpPost]
        public async Task<IActionResult> Delete(Student studentModel)
        {
            var student = await dbContext.Students.AsNoTracking().FirstOrDefaultAsync(x => x.Id == studentModel.Id);
            if (student is not null)
            {
                dbContext.Students.Remove(student);
                await dbContext.SaveChangesAsync();
            }
            return RedirectToAction("List", "Student");
        }
    }
}
