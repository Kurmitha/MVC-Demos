﻿namespace StudentPortal.Web.Models
{
    public class StudentViewModel
    {
        public string Name { get; set; }
        public string Email { get; set; }

        public int Phone { get; set; }
        public bool Subscribed { get; set; }
    }
}
