﻿using Microsoft.AspNetCore.Mvc;
using Supermarket_Management_System.Web.Models;

namespace Supermarket_Management_System.Web.Controllers
{
    public class CategoriesController : Controller  
    {
        public IActionResult Index()
        {
            var categories = CategoriesRepository.GetCategories();
            return View(categories);
        }
        public IActionResult Edit(int? id)
        {
            // to use the partial view
            ViewBag.Action = "edit";
           var category = CategoriesRepository.GetCategorybyId(id.HasValue ? id.Value : 0);
           return View(category);
        }
        public IActionResult Add()
        {
            ViewBag.Action = "add";
            return View();
        }
        [HttpPost]
        public IActionResult Edit(Category category)
        {
            if (ModelState.IsValid)
            {
                CategoriesRepository.UpdateCategory(category.CategoryId, category);
                return RedirectToAction(nameof(Index));
            }
            return View(category);
        }
        [HttpPost]
        public IActionResult Add(Category category)
        {
            if (ModelState.IsValid)
            {
                CategoriesRepository.AddCategory(category);
                return RedirectToAction(nameof(Index));
            }
            // Log the validation errors
            var errors = ModelState.Values.SelectMany(v => v.Errors);
            foreach (var error in errors)
            {
                Console.WriteLine(error.ErrorMessage);  // Log or display errors
            }
            return View(category);
        }
        public IActionResult Delete(int categoryId)
        {
            CategoriesRepository.DeteleCategory(categoryId);
            return RedirectToAction(nameof(Index));
        }
    }
}
