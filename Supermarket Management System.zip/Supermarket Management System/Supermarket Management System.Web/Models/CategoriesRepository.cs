﻿namespace Supermarket_Management_System.Web.Models
{
    public static class CategoriesRepository
    {
        private static List<Category> _categories = new List<Category>()
        {
            new Category{ CategoryId = 1, Description="Bevarage", Name="Bevarage"},
            new Category{ CategoryId = 2, Description="Bakery", Name="Bakery"},
            new Category{ CategoryId = 3, Description="Meat", Name="Meat"}
        };

        public static void AddCategory(Category category)
        {
            var max = _categories.Max(x => x.CategoryId);
            category.CategoryId = max + 1;
            _categories.Add(category);
        }

        public static List<Category> GetCategories() => _categories;

        public static Category? GetCategorybyId(int categoryID)
        {
            var category = _categories.FirstOrDefault(x => x.CategoryId == categoryID);
            if(category!=null)
            {
                return new Category
                {
                    CategoryId = category.CategoryId,
                    Description = category.Description,
                    Name = category.Name,
                };
            }
            return null;
        }

        public static void UpdateCategory(int categoryID, Category category)
        {
            if (categoryID != category.CategoryId) return;
            var categorytoUpdate = _categories.FirstOrDefault(x => x.CategoryId == categoryID);
            if (categorytoUpdate != null)
            {
                categorytoUpdate.Name = category.Name;
                categorytoUpdate.Description = category.Description;
            }
        }
        public static void DeteleCategory(int categoryId)
        {
            var category = _categories.FirstOrDefault(x => x.CategoryId == categoryId);
            if (category != null)
            {
                _categories.Remove(category);
            }
        }
    }
}
